import re
from sklearn.metrics.pairwise import cosine_similarity
from sklearn.feature_extraction.text import CountVectorizer
import networkx as nx

def tokenize_sentences(text):
    """
    Tokenizes the text into sentences using a regex-based approach.
    """
    sentence_pattern = r'(?<!\w\.\w.)(?<![A-Z][a-z]\.)(?<=\.|\?)\s'
    sentences = re.split(sentence_pattern, text.strip())
    return [sentence.strip() for sentence in sentences if sentence.strip()]

def preprocess(sentence, stop_words):
    """
    Preprocesses a sentence by removing stopwords and non-alphanumeric characters.
    """
    tokens = re.findall(r'\b\w+\b', sentence.lower())
    return ' '.join([word for word in tokens if word not in stop_words])

def text_rank_summarization(text, num_sentences=3):
    """
    Summarizes the input text using an extractive summarization technique (TextRank).
    
    :param text: The original text to summarize
    :param num_sentences: Number of sentences to include in the summary
    :return: Concise summary of the text
    """
    # Tokenize sentences
    sentences = tokenize_sentences(text)

    # Define a basic set of stopwords
    stop_words = set([
        'a', 'an', 'and', 'are', 'as', 'at', 'be', 'by', 'for', 'from',
        'has', 'he', 'in', 'is', 'it', 'its', 'of', 'on', 'that', 'the',
        'to', 'was', 'were', 'will', 'with'
    ])

    # Preprocess sentences
    processed_sentences = [preprocess(sentence, stop_words) for sentence in sentences]

    # Create the similarity matrix
    vectorizer = CountVectorizer().fit_transform(processed_sentences)
    vectors = vectorizer.toarray()
    similarity_matrix = cosine_similarity(vectors)

    # Build the graph and compute TextRank scores
    graph = nx.from_numpy_array(similarity_matrix)
    scores = nx.pagerank(graph)

    # Rank sentences and extract top sentences
    ranked_sentences = sorted(((scores[i], s) for i, s in enumerate(sentences)), reverse=True)
    summary = ' '.join([ranked_sentences[i][1] for i in range(min(num_sentences, len(ranked_sentences)))])
    return summary

# Example Usage
text = """
Artificial Intelligence (AI) is a rapidly evolving field that has the potential to revolutionize numerous industries.
AI enables machines to learn from data and perform tasks that typically require human intelligence.
The applications of AI range from natural language processing and computer vision to robotics and predictive analytics.
As AI technologies advance, they are increasingly being integrated into everyday tools and systems, improving efficiency and decision-making.
However, the growth of AI also raises ethical and societal concerns, including privacy issues and job displacement.
"""

summary = text_rank_summarization(text, num_sentences=2)
print("Original Text:")
print(text)
print("\nSummary:")
print(summary)

