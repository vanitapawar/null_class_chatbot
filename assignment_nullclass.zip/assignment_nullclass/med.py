import streamlit as st
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
import re

# Load the dataset
@st.cache_data
def load_data(file_path):
    df = pd.read_csv(file_path)
    return df

# Function for entity recognition
def entity_recognition(text):
    # Basic regex patterns for demonstration
    symptoms_pattern = r"(fever|cough|pain|headache|rash)"
    diseases_pattern = r"(diabetes|hypertension|asthma|cancer)"
    treatments_pattern = r"(medication|surgery|therapy|exercise)"
    
    entities = {
        "Symptoms": re.findall(symptoms_pattern, text, re.IGNORECASE),
        "Diseases": re.findall(diseases_pattern, text, re.IGNORECASE),
        "Treatments": re.findall(treatments_pattern, text, re.IGNORECASE),
    }
    return {key: list(set(value)) for key, value in entities.items() if value}

# TF-IDF-based retrieval mechanism
@st.cache_resource
def create_retrieval_model(data):
    vectorizer = TfidfVectorizer(stop_words='english')  
    tfidf_matrix = vectorizer.fit_transform(data['question'])
    return vectorizer, tfidf_matrix

def retrieve_answer(user_question, vectorizer, tfidf_matrix, data):
    user_tfidf = vectorizer.transform([user_question])
    similarities = cosine_similarity(user_tfidf, tfidf_matrix)
    idx = similarities.argmax()
    # Check if 'focus_area' column exists in the dataset
    focus_area = data.iloc[idx].get('focus_area', 'Not Available')
    return data.iloc[idx]['answer'], data.iloc[idx]['source'], focus_area

# Streamlit UI
def main():
    st.title("Medical Question-Answering Chatbot")
    st.markdown("Ask any medical question, and I'll try to provide the best answer!")

    # Load dataset
    file_path = r"C:\Users\Dell\Documents\job_aaj_sql\medquad.csv"  # Replace with your dataset file path
    data = load_data(file_path)

    # Create retrieval model
    vectorizer, tfidf_matrix = create_retrieval_model(data)

    # User input
    user_question = st.text_input("Enter your medical question:")
    
    if user_question:
        # Entity recognition
        entities = entity_recognition(user_question)
        if entities:
            st.write("Recognized Entities:", entities)

        # Retrieve answer
        answer, source, focus_area = retrieve_answer(user_question, vectorizer, tfidf_matrix, data)
        st.subheader("Answer:")
        st.write(answer)
        st.write(f"**Source:** {source}")
        st.write(f"**Focus Area:** {focus_area}")

if __name__ == "__main__":
    main()
